import { Validator } from "./types/cosmos/base/tendermint/v1beta1/query"
import { VersionInfo } from "./types/cosmos/base/tendermint/v1beta1/query"
import { Module } from "./types/cosmos/base/tendermint/v1beta1/query"


export {     
    Validator,
    VersionInfo,
    Module,
    
 }