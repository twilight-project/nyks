import { GeneratedType } from "@cosmjs/proto-signing";

const msgTypes: Array<[string, GeneratedType]>  = [
    
];

export { msgTypes }