import { ParameterChangeProposal } from "./types/cosmos/params/v1beta1/params"
import { ParamChange } from "./types/cosmos/params/v1beta1/params"


export {     
    ParameterChangeProposal,
    ParamChange,
    
 }