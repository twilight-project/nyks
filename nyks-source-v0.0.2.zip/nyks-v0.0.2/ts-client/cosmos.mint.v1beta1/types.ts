import { Minter } from "./types/cosmos/mint/v1beta1/mint"
import { Params } from "./types/cosmos/mint/v1beta1/mint"


export {     
    Minter,
    Params,
    
 }