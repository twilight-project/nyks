import { Equivocation } from "./types/cosmos/evidence/v1beta1/evidence"


export {     
    Equivocation,
    
 }